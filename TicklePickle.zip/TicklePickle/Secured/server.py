#!/usr/bin/python3

import os
import pickle
import base64
import hashlib
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad,unpad

__key__ = hashlib.sha256(b'AAAABBBBCCCCDDDD').digest()


def decrypt(enc):
    enc = base64.b64decode(enc)
    iv = enc[:AES.block_size]
    cipher = AES.new(__key__, AES.MODE_CFB, iv)
    return unpad(base64.b64decode(cipher.decrypt(enc[AES.block_size:])),16)


def reverse_fun():
      with open("users.json","rb") as f:
          data = decrypt(f.read())
      
      d = pickle.loads(data)
      return d

if __name__ == '__main__':
      print(reverse_fun())

 
# Vulnerability: Pickle Code Execution

## Python Pickle Security Best Practices

- If possible, encrypt the network connection between the machines communicating pickled data. This will prevent modification of pickled data. Using SSL/TLS to encrypt network connections between systems is very common and effective in preventing attackers from tampering with network traffic.
- If network connection encryption is not possible, use a digital signature to maintain data integrity and ensure network traffic is not altered in transit.
- If pickled data is stored to a disk, ensure strict file permissions are applied to prevent someone from modifying the pickled data.
- Since it is easy to execute arbitrary code when unpickling data, it may be best to avoid using the Pickle module. Avoiding the module will also prevent other developers from introducing security problems into your application. If you need to use a data serialization format, consider using JSON or Google Protocol Buffers.

[Source](https://www.smartfile.com/blog/python-pickle-security-problems-and-solutions)

